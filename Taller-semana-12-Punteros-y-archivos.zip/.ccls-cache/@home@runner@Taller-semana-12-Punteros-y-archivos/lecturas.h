int leerEntero(char* );
int leerEnteroPositivo(char* );
int leerEnteroEntre(char*,int,int);

float leerFlotante(char* );
float leerFlotantePositivo(char* );
float leerFlotanteEntre(char*, float, float);

char leerCaracter(char* );